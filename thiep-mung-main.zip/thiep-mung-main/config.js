const nameGirl = 'Phụ nữ VN';
const giftUrl = 'http://nodemy.vn';
const eventName = 'Chúc Mừng 8/3';
const titleCard = 'Tặng Mẹ và Năm';
const contentCard = 'Chúc mẹ và năm luôn hạnh phúc, vui vẻ, lâu già và kiếm được nhiều tiền để cuối năm gđ mình cùng đi chơi, con đang ở nơi xa dùi mài kinh sử không thể cùng mẹ tận hưởng niềm vui này :))';


const giftImage = 'anhme.jpg';
const base64 = '';
const giftImageBase64 = "data:image/png;base64, " + base64;
